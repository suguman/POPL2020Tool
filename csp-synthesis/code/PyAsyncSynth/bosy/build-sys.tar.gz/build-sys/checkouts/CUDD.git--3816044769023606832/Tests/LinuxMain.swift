import XCTest
@testable import CUDDTests

XCTMain([
     testCase(CUDDTests.allTests),
])
