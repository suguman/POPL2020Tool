# Aiger

A lightweight, swifty (and incomplete) wrapper around the C [AIGER](http://fmv.jku.at/aiger/) library.

## Feautures

* Iteration over inputs, latches, and outputs
* Lookup of literals


# Installation

## Swift Package Manager

```swift
.Package(url: "https://github.com/ltentrup/Aiger.git", majorVersion: 0, minor: 2)
```
