import XCTest
@testable import AigerTests

XCTMain([
     testCase(AigerTests.allTests),
])
