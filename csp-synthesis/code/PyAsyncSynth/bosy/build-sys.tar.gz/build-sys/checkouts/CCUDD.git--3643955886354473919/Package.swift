import PackageDescription

let package = Package(
    name: "CCUDD",
    targets: [
        Target(name: "CCUDD"),
    ]
)
