# CAiger

A Swift Package Manager module containing the [AIGER](http://fmv.jku.at/aiger/) library.

# Installation

## Swift Package Manager

```swift
.Package(url: "https://github.com/ltentrup/CAiger.git", majorVersion: 0, minor: 1)
```
