import XCTest
@testable import CAigerTests

XCTMain([
     testCase(CAigerTests.allTests),
])
